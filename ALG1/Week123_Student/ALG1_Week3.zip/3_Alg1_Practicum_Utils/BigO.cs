﻿
namespace Alg1_Practicum_Utils
{
    public enum BigO { One, LogN, N, N2, N3, N4, N5, N6, N7, N8, N9, N10 }; 

}